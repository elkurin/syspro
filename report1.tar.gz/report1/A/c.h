#ifndef C_H_INCLUDED
#define C_H_INCLUDED

char *hello_c(void);

#endif
