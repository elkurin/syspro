tnode *btree_create();
tnode *btree_insert(int v, tnode *t);
void btree_destroy(tnode *t);
void btree_dunp(tnode *t);

