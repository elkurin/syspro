char *hello_c(void)
{
	char *r = "Hello, C world!\n";
	return r;
}
